/* 詩:그널 — 오리엔탈 배경음악 (WebAudio 실시간 합성 · 외부 음원 없음)
   악기: 고쟁(플럭) 아르페지오 · 디즈(피리) 선율 · 소나 · 북 · 목탁 · 방울 · 징
   곡마다 조성(오음 선법)·빠르기·주선율 악기·북 패턴이 다르다. */
const MUSIC = (() => {
  const MODES = { gong: [0, 2, 4, 7, 9], shang: [0, 2, 5, 7, 10], zhi: [0, 2, 5, 7, 9], yu: [0, 3, 5, 7, 10] };
  // m: 8분음표 8칸 × 4마디 (숫자=음계 도수, -=붙임, .=쉼)  r: 마디별 베이스 도수
  const THEMES = [
    { m: ['5-765-3-', '235-320-', '5-789-87', '6-5-675-'], r: [0, -1, -2, 1] },
    { m: ['5-765-3-', '235-6532', '35320-12', '0---....'], r: [0, -1, 1, 0] },
    { m: ['7-8-987-', '875-6-5-', '356-5323', '5---.567'], r: [-2, -1, 0, -2] },
    { m: ['9-878-75', '6-567-5-', '32352-10', '0---....'], r: [-1, 1, -2, 0] },
  ];
  const SONGS = {
    title: { key: 62, mode: 'gong', bpm: 116, lead: 'dizi', alt: 'pluck', drums: 2, order: [0, 1, 2, 3] },
    qin:   { key: 62, mode: 'gong', bpm: 108, lead: 'dizi', alt: 'pluck', drums: 1, order: [2, 3, 0, 1] },
    su:    { key: 65, mode: 'zhi',  bpm: 126, lead: 'dizi', alt: 'pluck', drums: 2, order: [0, 3, 2, 1] },
    lu:    { key: 64, mode: 'shang', bpm: 112, lead: 'xiao', alt: 'pluck', drums: 1, order: [2, 1, 0, 3] },
    xin:   { key: 62, mode: 'yu',   bpm: 132, lead: 'suona', alt: 'dizi', drums: 3, order: [0, 1, 2, 3] },
    li:    { key: 67, mode: 'zhi',  bpm: 114, lead: 'pluck', alt: 'dizi', drums: 1, order: [1, 0, 3, 2] },
    study: { key: 65, mode: 'gong', bpm: 98,  lead: 'pluck', alt: 'xiao', drums: 0, order: [0, 1, 2, 3] },
  };
  let ctx, out, rev, bus, timer = null, cur = 'title', on = false, bar = 0, nt = 0;
  const cache = {};
  const mtof = m => 440 * Math.pow(2, (m - 69) / 12);

  function init() {
    if (ctx) return ctx;
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -16; comp.ratio.value = 3;
    out = ctx.createGain(); out.gain.value = .5; out.connect(comp); comp.connect(ctx.destination);
    rev = ctx.createConvolver(); rev.buffer = impulse(2.6);
    const rg = ctx.createGain(); rg.gain.value = .32; rev.connect(rg); rg.connect(comp);
    return ctx;
  }
  function impulse(sec) {
    const n = Math.floor(ctx.sampleRate * sec), b = ctx.createBuffer(2, n, ctx.sampleRate);
    for (let c = 0; c < 2; c++) { const d = b.getChannelData(c); for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 2.8); }
    return b;
  }
  function noiseBuf() {
    if (cache.noise) return cache.noise;
    const n = ctx.sampleRate, b = ctx.createBuffer(1, n, ctx.sampleRate), d = b.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    return (cache.noise = b);
  }
  // Karplus-Strong 현 뜯는 소리 (고쟁 느낌)
  function ksBuf(m) {
    if (cache[m]) return cache[m];
    const sr = ctx.sampleRate, N = Math.max(2, Math.round(sr / mtof(m))), len = Math.floor(sr * 1.9);
    const b = ctx.createBuffer(1, len, sr), d = b.getChannelData(0);
    for (let i = 0; i < N; i++) d[i] = Math.random() * 2 - 1;
    for (let i = 1; i < N; i++) d[i] = (d[i] + d[i - 1]) * .5;
    const damp = m > 84 ? .985 : m > 74 ? .993 : .997;
    for (let i = N; i < len; i++) d[i] = damp * .5 * (d[i - N] + d[i - N + 1 < i ? i - N + 1 : i - N]);
    return (cache[m] = b);
  }
  function send(node, wet = .5, pan = 0) {
    let n = node;
    if (pan && ctx.createStereoPanner) { const p = ctx.createStereoPanner(); p.pan.value = pan; node.connect(p); n = p; }
    n.connect(bus);
    if (wet) { const g = ctx.createGain(); g.gain.value = wet; n.connect(g); g.connect(rev); }
  }
  function env(g, t, a, peak, hold, rel) {
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(peak, t + a);
    g.gain.setValueAtTime(peak, t + a + hold);
    g.gain.exponentialRampToValueAtTime(0.0001, t + a + hold + rel);
  }

  /* ── 악기 ── */
  function pluck(t, m, v = .3, pan = 0) {
    const s = ctx.createBufferSource(), g = ctx.createGain();
    s.buffer = ksBuf(m); g.gain.value = v; s.connect(g); send(g, .45, pan);
    s.start(t); s.stop(t + 1.9);
  }
  function wind(t, m, dur, kind) {
    const f = mtof(m), o = ctx.createOscillator(), o2 = ctx.createOscillator(), g = ctx.createGain(), g2 = ctx.createGain();
    const lfo = ctx.createOscillator(), lg = ctx.createGain();
    const P = { dizi: { v: .085, vib: 5.6, dep: .009, t1: 'sine', t2: 'triangle', h: 2, br: .35 },
                xiao: { v: .09,  vib: 4.6, dep: .006, t1: 'sine', t2: 'sine', h: 1, br: .5 },
                suona:{ v: .035, vib: 6.2, dep: .012, t1: 'sawtooth', t2: 'square', h: 1, br: .1 } }[kind];
    o.type = P.t1; o2.type = P.t2;
    o.frequency.setValueAtTime(f * .965, t); o.frequency.exponentialRampToValueAtTime(f, t + .06);
    o2.frequency.setValueAtTime(f * P.h * .965, t); o2.frequency.exponentialRampToValueAtTime(f * P.h, t + .06);
    g2.gain.value = kind === 'suona' ? .6 : .18;
    lfo.frequency.value = P.vib;
    lg.gain.setValueAtTime(0, t); lg.gain.linearRampToValueAtTime(f * P.dep, t + Math.min(.3, dur * .7));
    lfo.connect(lg); lg.connect(o.frequency); lg.connect(o2.frequency);
    o.connect(g); o2.connect(g2); g2.connect(g);
    let last = g;
    if (kind === 'suona') { const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = f * 5; lp.Q.value = 2; g.connect(lp); last = lp; }
    env(g, t, .035, P.v, Math.max(.02, dur - .1), .14);
    send(last, .55, .08);
    // 숨소리
    const n = ctx.createBufferSource(), bp = ctx.createBiquadFilter(), ng = ctx.createGain();
    n.buffer = noiseBuf(); bp.type = 'bandpass'; bp.frequency.value = f * 1.6; bp.Q.value = 1.4;
    n.connect(bp); bp.connect(ng); env(ng, t, .02, P.v * P.br, Math.max(.02, dur - .12), .1); send(ng, .3, .08);
    const end = t + dur + .3;
    [o, o2, lfo].forEach(x => { x.start(t); x.stop(end); }); n.start(t, Math.random() * .5); n.stop(end);
  }
  function bass(t, m, dur, v = .2) {
    const o = ctx.createOscillator(), lp = ctx.createBiquadFilter(), g = ctx.createGain();
    o.type = 'triangle'; o.frequency.value = mtof(m); lp.type = 'lowpass'; lp.frequency.value = 520;
    o.connect(lp); lp.connect(g); env(g, t, .012, v, dur * .3, dur * .8); send(g, .15);
    o.start(t); o.stop(t + dur * 1.3 + .1);
  }
  function drum(t, v = .5, hi = false) {
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.frequency.setValueAtTime(hi ? 220 : 150, t); o.frequency.exponentialRampToValueAtTime(hi ? 110 : 52, t + .18);
    o.connect(g); env(g, t, .004, v, .01, hi ? .22 : .38); send(g, .2);
    o.start(t); o.stop(t + .5);
    const n = ctx.createBufferSource(), lp = ctx.createBiquadFilter(), ng = ctx.createGain();
    n.buffer = noiseBuf(); lp.type = 'lowpass'; lp.frequency.value = 1400;
    n.connect(lp); lp.connect(ng); env(ng, t, .002, v * .35, .005, .06); send(ng, .1);
    n.start(t, Math.random() * .5); n.stop(t + .12);
  }
  function wood(t, v = .16, hi = false) {
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = 'sine'; o.frequency.value = hi ? 1320 : 960;
    o.connect(g); env(g, t, .002, v, .004, .07); send(g, .25, hi ? .25 : -.25);
    o.start(t); o.stop(t + .12);
  }
  function shaker(t, v = .02) {
    const n = ctx.createBufferSource(), hp = ctx.createBiquadFilter(), g = ctx.createGain();
    n.buffer = noiseBuf(); hp.type = 'highpass'; hp.frequency.value = 6500;
    n.connect(hp); hp.connect(g); env(g, t, .004, v, .005, .045); send(g, .1, .3);
    n.start(t, Math.random() * .5); n.stop(t + .08);
  }
  function bell(t, v = .05) {
    [2093, 5776].forEach((f, i) => {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.frequency.value = f; o.connect(g); env(g, t, .002, v / (i + 1), .01, .7); send(g, .6, -.3);
      o.start(t); o.stop(t + .8);
    });
  }
  function gong(t, v = .1) {
    [98, 146.5, 207, 291].forEach((f, i) => {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.frequency.setValueAtTime(f * 1.01, t); o.frequency.exponentialRampToValueAtTime(f, t + 1.2);
      o.connect(g); env(g, t, .02, v / (1 + i * .6), .05, 3.2); send(g, .7);
      o.start(t); o.stop(t + 3.5);
    });
  }

  /* ── 편곡 ── */
  const parsed = THEMES.map(th => th.m.map(s => {
    const ev = [];
    for (let i = 0; i < 8; i++) {
      const c = s[i];
      if (c >= '0' && c <= '9') { let len = 1; while (s[i + len] === '-') len++; ev.push([i, +c, len]); }
    }
    return ev;
  }));
  function deg(song, d, base) {
    const M = MODES[song.mode], o = Math.floor(d / 5), i = ((d % 5) + 5) % 5;
    return base + 12 * o + M[i];
  }
  function lead(kind, t, m, dur, slot) {
    if (kind === 'pluck') {
      pluck(t, m, .34, .1);
      if (dur > .5) for (let k = .085; k < dur - .05; k += .085) pluck(t + k, m, .1, .1); // 고쟁 트레몰로
      return;
    }
    if (dur > .3 && slot % 4 === 0) wind(t - .045, m + 2, .04, kind); // 꾸밈음
    wind(t, kind === 'xiao' ? m - 12 : m, dur, kind);
  }
  function scheduleBar(t) {
    const s = SONGS[cur], q = 60 / s.bpm, e = q / 2, x = q / 4; // 4분/8분/16분
    const intro = bar < 2, sec = intro ? 0 : (bar - 2) % 32, pass = Math.floor(sec / 16);
    const ti = s.order[Math.floor((sec % 16) / 4)], bi = sec % 4, th = THEMES[ti];
    const root = intro ? 0 : th.r[bi];
    if (bar === 0 || (!intro && sec === 0)) gong(t, .09);
    // 고쟁 아르페지오
    const arpBase = s.key - 24;
    if (pass === 0 || intro) {
      [5, 6, 7, 8, 10, 8, 7, 6].forEach((d, i) => pluck(t + i * e, deg(s, root + d, arpBase), i ? .11 : .16, -.2));
    } else {
      [5, 7, 8, 10, 8, 7, 6, 7, 5, 7, 8, 10, 11, 10, 8, 7].forEach((d, i) => pluck(t + i * x, deg(s, root + d, arpBase), i % 4 ? .07 : .12, -.25));
    }
    bass(t, deg(s, root, s.key - 24), q * 1.6);
    bass(t + q * 2, deg(s, root, s.key - 24), q * 1.4, .15);
    if (!intro && bi === 3) bass(t + q * 3.5, deg(s, root + 1, s.key - 24), q * .5, .12);
    // 주선율
    if (!intro) {
      const kind = pass === 0 ? s.lead : s.alt;
      parsed[ti][bi].forEach(([slot, d, len]) => lead(kind, t + slot * e, deg(s, d, s.key), len * e * .95, slot));
      if (pass === 1 && s.alt !== 'pluck') parsed[ti][bi].forEach(([slot, d]) => pluck(t + slot * e, deg(s, d, s.key + 12), .07, .3));
    }
    // 타악
    const lv = intro ? Math.min(1, s.drums) : s.drums, fill = !intro && sec % 16 === 15;
    for (let k = 0; k < 16; k++) {
      const tt = t + k * x;
      if (lv >= 1) {
        const D = lv === 1 ? [0, 10] : lv === 2 ? [0, 3, 8, 10] : [0, 2, 3, 6, 8, 10, 11, 14];
        if (D.includes(k)) drum(tt, k === 0 || k === 8 ? .5 : .32);
        if (fill && k >= 12) drum(tt, .28 + (k - 12) * .06, true);
        if (k % 2 === 0) shaker(tt, k % 4 === 0 ? .022 : .012);
        else if (lv >= 2) shaker(tt, .008);
      }
      if ([4, 12].includes(k)) wood(tt, lv ? .15 : .1, k === 12);
      if (lv >= 2 && k === 14) wood(tt, .08, true);
    }
    if (bar % 2 === 1 && lv >= 1) bell(t + q * 2, .035);
    if (lv === 0 && bar % 2 === 0) bell(t, .03);
  }
  function tick() {
    if (!on) return;
    const s = SONGS[cur], barDur = 4 * 60 / s.bpm;
    while (nt < ctx.currentTime + .35) { scheduleBar(nt); nt += barDur; bar++; }
  }
  function newBus() {
    if (bus) { const old = bus; old.gain.setTargetAtTime(0, ctx.currentTime, .12); setTimeout(() => old.disconnect(), 1500); }
    bus = ctx.createGain(); bus.gain.value = 1; bus.connect(out);
    bar = 0; nt = ctx.currentTime + .08;
  }
  return {
    get ctx() { return init(); },
    get playing() { return on; },
    start(id) { init(); ctx.resume(); if (id && SONGS[id]) cur = id; on = true; newBus(); clearInterval(timer); timer = setInterval(tick, 40); tick(); },
    stop() { on = false; clearInterval(timer); if (bus) { const old = bus; old.gain.setTargetAtTime(0, ctx.currentTime, .1); setTimeout(() => old.disconnect(), 800); bus = null; } },
    play(id) { if (!SONGS[id] || id === cur) return; cur = id; if (on) { newBus(); tick(); } },
    song: () => cur,
  };
})();
