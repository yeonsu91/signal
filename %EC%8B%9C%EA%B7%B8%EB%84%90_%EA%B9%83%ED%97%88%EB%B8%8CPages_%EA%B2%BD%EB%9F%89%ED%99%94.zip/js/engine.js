/* 詩:그널 — 다섯 스승 편 · 공통 엔진
   ROUTES(data/route_*.js) · POEMS(data/poems.js) · MUSIC(js/music.js)를 읽는다. */
const $ = s => document.querySelector(s), app = $('#app'), A = 'assets/';
const senses = ['시각', '청각', '후각', '미각', '촉각'], glyphs = ['景', '聲', '香', '味', '觸'];
const RANKS = [[0, '지나가던 길손'], [3, '새 제자'], [6, '믿음직한 제자'], [9, '아끼는 제자'], [12, '애제자(愛弟子)']], MAXA = 14;
const josa = (w, a, b) => { const c = w.charCodeAt(w.length - 1) - 0xAC00; return w + (c >= 0 && c <= 11171 && c % 28 ? a : b); };
const esc = t => String(t).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/* ── 귀환 · 시험 (모든 루트 공통 에필로그) ── */
function EPI(r) {
  return [
    { tag: '歸 · 돌아온 자리', title: '눈을 뜨니 도서관', place: '중앙도서관 열람실 · 새벽', lines: [
      ['', '…툭. 이마에 닿은 것은 차가운 책상이었다.', 'none'],
      ['나', '…도서관?'],
      ['', '스탠드 불빛 아래 시집이 펼쳐져 있다. 비어 있던 다섯 페이지에 글자가 빼곡하다.'],
      ['', `${r.memories[0]}, ${r.memories[2]}, ${r.memories[4]}… 페이지를 넘길 때마다 장면들이 잔상처럼 겹친다.`],
      ['', `책갈피 뒷면에는 낯익은 필체가 남아 있다. ${r.name} 스승님의 글씨다.`],
      ['나', '꿈이었나…? 그런데 눈이, 귀가, 손끝이 아직 기억하고 있어.'],
      ['', '휴대전화가 진동한다. ‘중국고전시가 II 기말고사 · 오늘 오전 9시.’'],
      ['나', '…맞다, 시험! 그런데 이상하게, 하나도 무섭지 않아.'],
    ] },
    { tag: '試 · 기말고사', title: '시를 치르는 아침', place: '인문관 강의실 · 오전 9시', lines: [
      ['', '봄 햇살이 드는 강의실. 시험지가 앞자리에서부터 한 장씩 넘어온다.', 'none'],
      ['나', '(심호흡. 외운 대로가 아니라, 본 대로 쓰자.)'],
      { exam: 0 }, { exam: 1 }, { exam: 2 },
      ['', '마지막 칸을 채우고 펜을 내려놓는다. 창밖에서 꽃잎 하나가 시험지 위로 날아든다.'],
      ['나', `(시험지에 적은 건 정답이지만, 마음에 남은 건 ${r.name} 스승님과 함께 본 풍경이었다.)`],
      ['', `종이 울린다. 시험지를 걷어 가는 소리 사이로, 문득 ${josa(r.name, '의', '의')} 웃음소리가 들린 것만 같았다.`],
    ] },
  ];
}

/* ── 상태 ── */
const fresh = () => ({ chapter: 0, furthest: 0, line: 0, phase: 'lines', done: [], choices: {}, exam: {}, affinity: 0, started: false, ended: false, history: [], hub: false, finale: false });
let R = ROUTES[0], CH = [], state = fresh(), current = 0, cleanup = () => {}, sound = false, auto = false, autoTimer, typeTimer, textComplete = true, screen = 'title', reply = '', curExpr = 'base', lastSprite = false;
const KEY = id => 'sig5-' + id;
function readSave(id, suffix = '') { try { const s = JSON.parse(localStorage.getItem(KEY(id) + suffix)); if (s && Number.isInteger(s.chapter) && s.chapter >= 0 && s.chapter < 9) return { ...fresh(), ...s }; } catch {} return null; }
function loadRoute(id) { R = ROUTES.find(r => r.id === id) || ROUTES[0]; CH = [...R.chapters, ...EPI(R)]; state = readSave(R.id) || fresh(); }
function save(suffix = '') { try { localStorage.setItem(KEY(R.id) + suffix, JSON.stringify(state)); localStorage.setItem('sig5-last', R.id); return true; } catch { toast('저장 공간을 사용할 수 없어요.'); return false; } }
function toast(t) { $('#toast').textContent = t; $('#toast').style.opacity = 1; clearTimeout(toast.timer); toast.timer = setTimeout(() => $('#toast').style.opacity = 0, 2300); }

/* ── 소리 ── */
function tone(freq = 440, dur = .15, gain = .045) {
  if (!sound) return;
  try { const c = MUSIC.ctx, o = c.createOscillator(), g = c.createGain(); o.type = 'sine'; o.frequency.value = freq; g.gain.setValueAtTime(gain, c.currentTime); g.gain.exponentialRampToValueAtTime(.001, c.currentTime + dur); o.connect(g); g.connect(c.destination); o.start(); o.stop(c.currentTime + dur); } catch {}
}
function songFor() { if (['title', 'select'].includes(screen)) return 'title'; if (screen !== 'ending' && state.chapter >= 7) return 'study'; return R.id; }
function soundLabel() { return sound ? '♫ 음악 ON' : '♫ 음악 OFF'; }
function toggleSound() { sound = !sound; sound ? MUSIC.start(songFor()) : MUSIC.stop(); document.querySelectorAll('#sound').forEach(b => { b.textContent = soundLabel(); b.setAttribute('aria-pressed', sound); }); }

function render(html) { cleanup(); cleanup = () => {}; clearInterval(typeTimer); clearTimeout(autoTimer); app.innerHTML = html; window.scrollTo(0, 0); updateGauge(); if (sound) MUSIC.play(songFor()); }

/* ── 그림 ── */
function bgFile(n = state.chapter) { if (screen === 'hub' || n === 0) return R.bg.prologue; if (n <= 5) return R.bg.senses[n - 1]; if (n === 6) return R.bg.finale; return n === 7 ? 'bg_library.jpg' : 'bg_exam.jpg'; }
function bg(n) { const f = bgFile(n), epi = (n ?? state.chapter) >= 7 && screen !== 'hub'; return `<div class="scene-bg bgx" style="background-image:url('${A}${f}')"></div><div class="scene-shade"></div>${epi ? '' : `<div class="petals" aria-hidden="true">${Array.from({ length: 9 }, (_, i) => `<i style="--i:${i}"></i>`).join('')}</div>`}`; }
function sprSrc() { if (screen === 'hub' || screen === 'intro') return A + R.sprites.smile; const n = state.chapter; if (R.outfits && n >= 1 && n <= 5) return A + R.outfits[n - 1]; return A + (R.sprites[curExpr] || R.sprites.base); }
function portrait(stay = false, cls = '') { return `<img class="qin-sprite${stay ? ' stay' : ''}${cls ? ' ' + cls : ''}" src="${sprSrc()}" alt="${R.name}">`; }
function pieces() { return `<div class="pieces">${glyphs.map((g, i) => `<span class="gem ${state.done.includes(i) ? 'lit' : ''}" title="${senses[i]}">${g}</span>`).join('')}</div>`; }

/* ── 신뢰 ── */
function rankOf(a) { let r = 0; RANKS.forEach((x, i) => { if (a >= x[0]) r = i; }); return r; }
function byBond(t) { if (!Array.isArray(t)) return t; const a = state.affinity; return t.length === 2 ? t[a >= 6 ? 1 : 0] : t[a >= 9 ? 2 : a >= 5 ? 1 : 0]; }
const REACT = n => ({ 2: `✦✦ ${josa(R.name, '의', '의')} 눈빛이 달라졌다 · 신뢰 +2`, 1: `✦ ${josa(R.name, '이', '가')} 고개를 끄덕인다 · 신뢰 +1`, 0: `${josa(R.name, '은', '는')} 담담히 받아 준다` }[n]);
function bondPop(n, rank = '') { document.querySelectorAll('.bond-pop').forEach(x => x.remove()); const p = document.createElement('div'); p.className = 'bond-pop' + (rank ? ' long' : ''); p.setAttribute('role', 'status'); p.innerHTML = '<b>신뢰 +' + n + '</b>' + (rank ? `<span>${josa(R.name, '이', '가')} 당신을 ‘${rank}’(으)로 여기기 시작했다.</span>` : ''); document.body.appendChild(p); setTimeout(() => p.remove(), rank ? 2900 : 2000); }
const GAUGE_ON = ['story', 'hub', 'game', 'reward'];
function updateGauge(glow = false) {
  const g = $('#trust'); if (!g) return;
  const on = GAUGE_ON.includes(screen) && state.started && state.chapter < 7;
  document.body.classList.toggle('trust-on', on); if (!on) return;
  const a = state.affinity, r = rankOf(a);
  if (!g.firstChild) g.innerHTML = '<div class="t-head">信</div><div class="t-track">' + RANKS.slice(1).map(x => '<span class="t-tick" title="' + x[1] + '" style="bottom:' + (x[0] / MAXA * 100) + '%"></span>').join('') + '<i class="t-fill"></i></div><div class="t-num"></div><div class="t-rank"></div>';
  $('.t-fill').style.height = Math.min(100, a / MAXA * 100) + '%';
  g.querySelectorAll('.t-tick').forEach((t, i) => t.classList.toggle('on', a >= RANKS[i + 1][0]));
  $('.t-num').innerHTML = '<b>' + a + '</b> / ' + MAXA; $('.t-rank').textContent = RANKS[r][1];
  g.title = `${R.name} · 사제의 정 · 신뢰 ${a} / ${MAXA}`; g.setAttribute('aria-label', `${R.name}의 신뢰`);
  if (glow) { g.classList.remove('glow'); void g.offsetWidth; g.classList.add('glow'); }
}

/* ── 툴바 ── */
function toolbar() { const hubOk = (state.furthest || 0) >= 1 && state.chapter < 7; return `<div class="vn-toolbar"><button id="titlebtn">詩:그널</button><div class="tools"><button id="sound" aria-pressed="${sound}">${soundLabel()}</button>${hubOk ? '<button id="hubbtn">감각 고르기</button>' : ''}<button id="logbtn">대화 기록</button><button id="bookbtn">시집</button><button id="savebtn">저장</button><button id="menubtn">메뉴 ☰</button></div></div>`; }
function bind() { const on = (s, f) => { const e = $(s); if (e) e.onclick = f; }; on('#hubbtn', () => hub()); on('#titlebtn', title); on('#sound', toggleSound); on('#logbtn', logs); on('#bookbtn', openbook); on('#savebtn', () => { if (save('-manual')) toast('현재 장면을 저장했어요.'); }); on('#menubtn', menu); }

/* ── 타이틀 · 스승 고르기 ── */
function title() {
  screen = 'title'; auto = false;
  const last = localStorage.getItem('sig5-last'), ls = last && readSave(last), lr = ls && ROUTES.find(r => r.id === last);
  const where = ls && ls.started ? lr.name + ' · ' + (ls.ended ? '완결' : ls.hub ? '감각 고르기' : [...lr.chapters, ...EPI(lr)][ls.chapter].tag) : '';
  const petals = Array.from({ length: 9 }, (_, i) => `<i style="--i:${i}"></i>`).join('');
  render(`<div class="title-kv"><div class="kv-art" style="background-image:url('${A}title_key.jpg')"></div><canvas class="kv-fx" aria-hidden="true"></canvas><div class="kv-shade"></div><div class="petals">${petals}</div>
<div class="kv-corner kv-left"><button id="sound" class="kv-chip" aria-pressed="${sound}">${soundLabel()}</button></div>
<div class="kv-corner kv-right"><button id="kvset" class="kv-icon" aria-label="설정"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 8.6a3.4 3.4 0 1 0 0 6.8 3.4 3.4 0 0 0 0-6.8Zm8.4 4.6-1.9.6-.5 1.3.9 1.8-1.6 1.6-1.8-.9-1.3.5-.6 1.9h-2.2l-.6-1.9-1.3-.5-1.8.9-1.6-1.6.9-1.8-.5-1.3-1.9-.6v-2.2l1.9-.6.5-1.3-.9-1.8 1.6-1.6 1.8.9 1.3-.5.6-1.9h2.2l.6 1.9 1.3.5 1.8-.9 1.6 1.6-.9 1.8.5 1.3 1.9.6Z"/></svg><span>설정</span></button><button id="collection" class="kv-icon" aria-label="작품과 제작 노트"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 5.5C5.8 4.2 8.9 4.3 12 6c3.1-1.7 6.2-1.8 9-.5v13c-2.8-1.3-5.9-1.2-9 .5-3.1-1.7-6.2-1.8-9-.5ZM12 6v13"/></svg><span>공지</span></button></div>
<section class="kv-center"><div class="kv-kicker">송시 오감 타임슬립 시뮬레이션</div><h1 class="kv-logo" aria-label="詩:그널 (시그널)"><svg class="kv-beat" viewBox="0 0 600 60" preserveAspectRatio="none" aria-hidden="true"><path d="M0 34H170l14-22 16 40 14-30 10 12H600"/></svg><span class="kv-si">詩</span><span class="kv-colon">:</span><span class="kv-name">그널</span><small>(시그널)</small></h1>
<div class="kv-sub">다섯 스승, 다섯 감각</div><p class="kv-tag">“시는 다 읽은 뒤에도<br>조금 더 계속되니까.”</p>
<button id="newgame" class="kv-start"><i>◆</i>게임 시작<i>◆</i></button>
${where ? `<button id="resume" class="kv-resume">이어하기 · ${where}</button>` : ''}</section></div>`);
  $('#sound').onclick = toggleSound; $('#newgame').onclick = select; $('#collection').onclick = credits;
  $('#kvset').onclick = () => { modal('설정', `<div class="menu-grid"><button id="sound" aria-pressed="${sound}">${soundLabel()}</button>${where ? `<button id="setresume">이어하기 · ${where}</button>` : ''}<button id="setcredits">작품과 제작 노트</button></div><p class="modal-intro">진행은 스승마다 자동 저장돼요. 클릭 · Enter · Space로 대사를 넘길 수 있어요.</p>`); $('#bookbody #sound').onclick = toggleSound; const r = $('#setresume'); if (r) r.onclick = () => { $('#book').close(); loadRoute(last); resume(); }; $('#setcredits').onclick = () => { $('#book').close(); credits(); }; };
  if (where) $('#resume').onclick = () => { loadRoute(last); resume(); };
  kvFx();
}
function kvFx() {
  const cv = $('.kv-fx'); if (!cv) return;
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const c = cv.getContext('2d'), dpr = Math.min(devicePixelRatio || 1, 2); let W, H, t0 = performance.now();
  const size = () => { W = cv.width = cv.clientWidth * dpr; H = cv.height = cv.clientHeight * dpr; }; size(); addEventListener('resize', size);
  const COL = ['#ffe9ef', '#f6c9d4', '#f3dcae', '#fff6e0', '#d9cdf0'], rnd = (a, b) => a + Math.random() * (b - a);
  const mk = kind => kind ? { k: 1, x: rnd(0, W), y: rnd(0, H), r: rnd(.6, 2.2) * dpr, ph: rnd(0, 6.28), sp: rnd(.4, 1.4), vy: rnd(-.25, -.05) * dpr } : { k: 0, x: rnd(-.2, 1) * W, y: rnd(-.3, 0) * H, s: rnd(5, 11) * dpr, a: rnd(0, 6.28), va: rnd(-.04, .04), vx: rnd(.6, 1.8) * dpr, vy: rnd(.7, 1.7) * dpr, w: rnd(0, 6.28), col: COL[Math.random() * COL.length | 0] };
  const P = [...Array(34)].map(() => { const p = mk(0); p.y = rnd(0, H); return p; });
  const loop = now => {
    if (!cv.isConnected) { removeEventListener('resize', size); return; }
    const t = (now - t0) / 1000; c.clearRect(0, 0, W, H);
    // swirl centre near the book
    const cx = W * .5, cy = H * .5;
    for (const p of P) {
      if (p.k) { p.y += p.vy; if (p.y < -5) { p.y = H + 5; p.x = rnd(0, W); } const al = .35 + .65 * Math.abs(Math.sin(t * p.sp + p.ph)); c.globalAlpha = al; c.fillStyle = '#fff2c9'; c.shadowColor = '#ffcf7a'; c.shadowBlur = 8 * dpr; c.beginPath(); c.arc(p.x, p.y, p.r * (0.6 + al * .6), 0, 6.28); c.fill(); continue; }
      const dx = p.x - cx, dy = p.y - cy, d = Math.hypot(dx, dy) + 1, pull = Math.min(1.6, 260 * dpr / d);
      p.x += p.vx + Math.sin(t * 1.3 + p.w) * .6 * dpr - dy / d * pull; p.y += p.vy + dx / d * pull * .5; p.a += p.va;
      if (p.y > H + 20 || p.x > W + 20 || p.x < -40) Object.assign(p, mk(0));
      c.globalAlpha = .85; c.shadowBlur = 6 * dpr; c.shadowColor = p.col; c.fillStyle = p.col; c.save(); c.translate(p.x, p.y); c.rotate(p.a); c.scale(1, .55 + .45 * Math.sin(t * 3 + p.w)); c.beginPath(); c.moveTo(0, -p.s); c.quadraticCurveTo(p.s * .8, 0, 0, p.s); c.quadraticCurveTo(-p.s * .8, 0, 0, -p.s); c.fill(); c.restore();
    }
    c.globalAlpha = 1; c.shadowBlur = 0; requestAnimationFrame(loop);
  };
  requestAnimationFrame(loop);
}
function resume() { state.ended ? ending() : state.hub ? hub() : state.started ? showLine() : chapterCard(); }
function select() {
  screen = 'select'; auto = false;
  render(`<div class="select-screen"><div class="cover" style="background-image:url('${A}title_five.jpg')"></div><div class="sel-shade"></div><div class="sel-top"><button id="back">← 타이틀</button><button id="sound" aria-pressed="${sound}">${soundLabel()}</button></div><section class="sel-wrap"><div class="eyebrow">師 · 스승 고르기</div><h2 class="sel-title">누구의 시집 속으로<br><span>떨어져 볼까?</span></h2><div class="sel-grid">${ROUTES.map(r => { const s = readSave(r.id); const st = s && s.ended ? '✦ 완결' : s && s.started ? '이어하기' : ''; return `<button class="poet-card" data-id="${r.id}"><img src="${A + r.sprites.base}" alt=""><div class="pc-body"><span class="pc-han">${r.han}</span><b>${r.name}</b><small>${r.subtitle.split(',').slice(1).join(',').trim() || r.subtitle}</small><p>${r.blurb}</p></div>${st ? `<span class="pc-status">${st}</span>` : ''}</button>`; }).join('')}</div></section></div>`);
  $('#back').onclick = title; $('#sound').onclick = toggleSound;
  document.querySelectorAll('.poet-card').forEach(b => b.onclick = () => { tone(520, .2); intro(b.dataset.id); });
}
function intro(id) {
  loadRoute(id); screen = 'intro'; const t = R.subtitle, k = t.indexOf(',');
  render(`<div class="chapter-card route-intro">${bg(0)}${portrait()}<div class="card-shade"></div><div class="card-glyph" aria-hidden="true">${R.han[0]}</div><section class="card-copy"><span class="card-tag">${R.badge}</span><h2>${k > 0 ? `${t.slice(0, k)}<br><span class="card-indent">${t.slice(k + 1).trim()}</span>` : t}</h2><p class="card-place">${R.quote.replace(/\n/g, '<br>')}</p><p class="intro-blurb">${R.blurb}</p><div class="intro-actions"><button id="startnew" class="pill">${state.started ? '처음부터 다시' : '이 시집 펼치기'} <i>→</i></button>${state.started ? `<button id="cont" class="pill ghost-pill">이어하기 · ${state.ended ? '완결' : state.hub ? '감각 고르기' : CH[state.chapter].tag}</button>` : ''}<button id="other" class="quiet">다른 스승 보기</button></div></section></div>`);
  $('#other').onclick = select;
  if ($('#cont')) $('#cont').onclick = resume;
  $('#startnew').onclick = () => { if (state.started) { modal('처음부터 다시', `<p>${josa(R.name, '과', '와')}의 자동 저장 기록이 초기화됩니다. 수동 저장은 남아 있습니다.</p><button id="confirmnew">새로 시작하기</button>`); $('#confirmnew').onclick = () => { $('#book').close(); start(); }; } else start(); };
}
function start() { state = fresh(); state.started = true; save(); chapterCard(); }

/* ── 감각 고르기 ── */
function poem(i) { return POEMS.find(p => p.poet.startsWith(R.name) && p.sense === senses[i]); }
function hub(sel) {
  screen = 'hub'; state.hub = true; state.furthest = Math.max(state.furthest || 0, 1); save();
  if (sel === undefined) { sel = [0, 1, 2, 3, 4].find(i => !state.done.includes(i)); if (sel === undefined) sel = 0; }
  const all = state.done.length >= 5, fin = CH[6];
  render(`<div class="hub">${bg(0)}${toolbar()}${portrait(true)}<section class="hub-wrap"><div class="eyebrow">${R.name}의 다섯 페이지 · 복원 ${state.done.length} / 5</div><h2 class="hub-title">어느 감각부터<br><span>되찾아 볼까?</span></h2><p class="hub-lead">순서는 자유롭게 고르세요. 다섯 페이지를 모두 되찾으면 마지막 장이 열립니다.</p><div class="sense-tabs" role="tablist" aria-label="감각 고르기">${senses.map((s, i) => `<button class="sense-tab${state.done.includes(i) ? ' done' : ''}" role="tab" data-tab="${i}" aria-selected="${i === sel}"><b>${glyphs[i]}</b>${s}</button>`).join('')}</div><div class="sense-panel" role="tabpanel" id="sensepanel"></div>${all ? `<button id="finale" class="pill">${fin.tag} · ${fin.title} <i>→</i></button>` : ''}</section></div>`);
  bind();
  const show = i => {
    sel = i; document.querySelectorAll('.sense-tab').forEach(b => b.setAttribute('aria-selected', +b.dataset.tab === i));
    const c = CH[i + 1], p = poem(i), done = state.done.includes(i);
    $('#sensepanel').innerHTML = `<div class="sp-glyph">${glyphs[i]}</div><div class="sp-body"><small>${senses[i]}의 페이지 · ${c.place}</small><h3>${c.title}</h3><p>${R.tease[i]}</p><p class="sp-poem">${p ? p.title : ''}</p><button id="opensense" class="pill">${done ? '다시 펼쳐 보기' : '이 페이지 펼치기'} <i>→</i></button>${done ? '<span class="sp-done">✦ 복원 완료</span>' : ''}</div>`;
    $('#opensense').onclick = () => { state.chapter = i + 1; state.line = 0; state.phase = 'lines'; state.hub = false; save(); chapterCard(); };
  };
  document.querySelectorAll('.sense-tab').forEach(b => b.onclick = () => { show(+b.dataset.tab); tone(440 + +b.dataset.tab * 60, .12); });
  $('.sense-tabs').onkeydown = e => { if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') { e.preventDefault(); const n = (sel + (e.key === 'ArrowRight' ? 1 : 4)) % 5; show(n); document.querySelector(`[data-tab="${n}"]`).focus(); } };
  show(sel);
  if ($('#finale')) $('#finale').onclick = () => { state.chapter = 6; state.line = 0; state.phase = 'lines'; state.hub = false; save(); chapterCard(); };
}

/* ── 장 표지 · 대사 ── */
function chapterCard() {
  screen = 'chapter'; curExpr = 'base';
  const n = state.chapter, c = CH[n], epi = n >= 7, g = n === 0 ? '序' : n === 6 ? '終' : n === 7 ? '歸' : n === 8 ? '試' : glyphs[c.sense];
  const t = c.title, k = t.lastIndexOf(' '), head = k > 0 ? `${t.slice(0, k)}<br><span class="card-indent">${t.slice(k + 1)}</span>` : t;
  render(`<div class="chapter-card${epi ? ' epi' : ''}">${bg(n)}${epi ? '' : portrait()}<div class="card-shade"></div><div class="card-glyph" aria-hidden="true">${g}</div><section class="card-copy"><span class="card-tag">${c.tag}</span><h2>${head}</h2><p class="card-place">${c.place}</p><button id="chaptergo" class="pill">이야기 펼치기 <i>→</i></button></section></div>`);
  $('#chaptergo').onclick = showLine;
}
function list() { const c = CH[state.chapter]; return state.phase === 'after' ? c.after : c.lines; }
function remember(who, text) { const key = `${state.chapter}:${state.phase}:${state.line}:${text}`; if (!state.history.some(x => x.key === key)) { state.history.push({ key, who, text }); if (state.history.length > 200) state.history.shift(); } }
function stage(c, inner, hidden, stay, cls = '') {
  return `<div class="vn-stage${cls}">${bg()}${toolbar()}<div class="chapter-label"><small>${c.tag} · ${c.place}</small><strong>${c.title}</strong></div>${!hidden ? portrait(stay) : ''}${state.chapter < 7 ? `<div class="page-count">${pieces()}<span>복원한 페이지 ${state.done.length} / 5</span></div>` : ''}${inner}</div>`;
}
function dialogue(who, bottom, extra = '') {
  return `<section class="dialogue ${who ? '' : 'narration'}"><div class="speaker">${who || '이야기'}${who === R.name ? `<small>${R.badge}</small>` : ''}</div><div id="spoken" aria-live="polite"></div><div class="dialogue-bottom">${bottom}</div></section>${extra}`;
}
function showLine() {
  const wasStory = screen === 'story'; screen = 'story'; state.hub = false; reply = '';
  if (state.chapter > (state.furthest || 0)) state.furthest = state.chapter;
  save();
  const c = CH[state.chapter]; let line = list()[state.line];
  if (!line) return completeChapter();
  if (line.game !== undefined) return mission(line.game);
  if (line.ending) return toLibrary();
  if (line.exam !== undefined) return examLine(line.exam);
  if (line.letter) line = [R.name, byBond(R.letters), 'smile'];
  const isChoice = !!line.choice, who = isChoice ? '나' : line[0], text = isChoice ? line.choice : byBond(line[1]);
  const hidden = state.chapter >= 7 || (!isChoice && line[2] === 'none');
  if (!isChoice && R.sprites[line[2]]) curExpr = line[2];
  remember(who, text);
  const stay = wasStory && lastSprite && !hidden; lastSprite = !hidden;
  const choices = isChoice ? `<div class="story-choices"><div class="choice-caption">당신의 대답은?</div>${line.options.map((o, i) => `<button data-choice="${i}">${o[0]} <span>◇</span></button>`).join('')}</div>` : '';
  const bottom = `<span>${isChoice ? `선택에 따라 ${josa(R.name, '의', '의')} 신뢰와 마지막 편지가 달라집니다.` : '클릭하거나 Enter를 눌러 계속'}</span><div><button id="auto" aria-pressed="${auto}">AUTO ${auto ? 'ON' : 'OFF'}</button>${!isChoice ? '<button id="nextline" aria-label="다음 대사">다음 ▷</button>' : ''}</div>`;
  render(stage(c, choices + dialogue(who, bottom), hidden, stay));
  bind(); typeText(text, isChoice);
  if (isChoice) document.querySelectorAll('[data-choice]').forEach(b => b.onclick = () => choose(line, +b.dataset.choice));
  else { $('#nextline').onclick = advance; $('.dialogue').onclick = e => { if (e.target.closest('button')) return; advance(); }; }
  $('#auto').onclick = () => { auto = !auto; $('#auto').textContent = 'AUTO ' + (auto ? 'ON' : 'OFF'); $('#auto').setAttribute('aria-pressed', auto); if (auto && textComplete && !isChoice) scheduleAuto(); else clearTimeout(autoTimer); };
  if (isChoice && ((state.chapter + ':' + state.line) in state.choices)) choose(line, state.choices[state.chapter + ':' + state.line]);
}
function typeText(text, immediate = false) {
  const el = $('#spoken'); el.dataset.full = text;
  textComplete = immediate || window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  el.textContent = textComplete ? text : '';
  if (textComplete) { if (auto && !immediate) scheduleAuto(); return; }
  let n = 0; typeTimer = setInterval(() => { n += 2; el.textContent = text.slice(0, n); if (n >= text.length) { clearInterval(typeTimer); textComplete = true; if (auto) scheduleAuto(); } }, 25);
}
function scheduleAuto() { clearTimeout(autoTimer); autoTimer = setTimeout(() => { if (screen === 'story' && !$('#book').open) advance(); }, Math.max(2000, ($('#spoken')?.dataset.full.length || 0) * 55)); }
function advance() {
  if (screen !== 'story') return;
  if (!textComplete) { clearInterval(typeTimer); $('#spoken').textContent = $('#spoken').dataset.full; textComplete = true; if (auto) scheduleAuto(); return; }
  if (reply) { reply = ''; state.line++; showLine(); return; }
  const l = list()[state.line]; if (l?.choice || l?.exam !== undefined) return;
  state.line++; showLine();
}
function choose(line, i) {
  clearInterval(typeTimer); clearTimeout(autoTimer);
  const o = line.options[i], key = state.chapter + ':' + state.line, first = !(key in state.choices), before = rankOf(state.affinity);
  if (first) { state.choices[key] = i; state.affinity += o[2]; }
  remember('나', o[0]); remember('이야기', o[1]); save(); reply = o[1];
  $('.story-choices').remove(); $('.speaker').textContent = '이야기'; $('.dialogue').classList.add('narration');
  $('#spoken').dataset.full = reply; $('#spoken').textContent = reply; textComplete = true;
  $('.dialogue-bottom').innerHTML = '<span>' + (first ? REACT(o[2]) : '선택한 마음이 기억되었습니다.') + '</span><button id="nextline">계속 ▷</button>';
  $('#nextline').onclick = advance; $('.dialogue').onclick = e => { if (e.target.closest('button')) return; advance(); };
  if (state.chapter === 0 || state.chapter === 6) { curExpr = o[2] > 0 ? 'smile' : 'base'; const im = $('.qin-sprite'); if (im) im.src = sprSrc(); }
  updateGauge(first && o[2] > 0);
  if (first && o[2] > 0) { const r = rankOf(state.affinity); bondPop(o[2], r > before ? RANKS[r][1] : ''); }
  tone(587, .4);
}
function completeChapter() {
  const was = state.chapter; state.line = 0; state.phase = 'lines';
  if (was === 6) return toLibrary();
  if (was === 7) { state.chapter = 8; save(); return chapterCard(); }
  if (was === 8) return ending();
  if (was >= 1 && state.done.length >= 5 && !state.finale) { state.finale = true; state.chapter = 6; state.hub = false; state.furthest = Math.max(state.furthest, 6); save(); return chapterCard(); }
  hub();
}
function toLibrary() { state.chapter = 7; state.line = 0; state.phase = 'lines'; state.hub = false; save(); chapterCard(); }

/* ── 기말고사 · 추억 ── */
function examLine(k) {
  const q = R.exam[k], c = CH[state.chapter]; reply = '';
  const choices = `<div class="story-choices exam-choices"><div class="choice-caption">문제 ${k + 1} / ${R.exam.length}</div>${q.choices.map((o, i) => `<button data-ans="${i}"><em>${'①②③④'[i]}</em> ${o}</button>`).join('')}</div>`;
  render(stage(c, choices + dialogue('시험지', '<span>답을 고르면 그때의 기억이 떠오릅니다.</span>'), true, false, ' exam-stage'));
  bind(); typeText(`문제 ${k + 1}. ${q.q}`, true);
  document.querySelectorAll('[data-ans]').forEach(b => b.onclick = () => { if (!(k in state.exam)) { state.exam[k] = +b.dataset.ans; save(); } recall(k); });
  if (k in state.exam) recall(k);
}
function recall(k) {
  const q = R.exam[k], ok = state.exam[k] === q.answer;
  remember('시험지', `문제 ${k + 1}. ${q.q} → ${q.choices[state.exam[k]]}`); remember('기억', q.recall);
  $('.story-choices')?.remove();
  const st = $('.vn-stage'); st.classList.add('recall');
  st.insertAdjacentHTML('beforeend', `<img class="qin-sprite ghost" src="${A + R.sprites.smile}" alt="${R.name}의 기억"><div class="exam-mark ${ok ? 'ok' : 'no'}">${ok ? '○' : '／'}</div>`);
  $('.speaker').innerHTML = `기억 <small>${R.name}</small>`; $('.dialogue').classList.remove('narration'); $('.dialogue').classList.add('memory');
  reply = q.recall; $('#spoken').dataset.full = ''; typeText(q.recall);
  $('.dialogue-bottom').innerHTML = `<span>${ok ? '✓ 정답 · ' + q.choices[q.answer] : '✗ 정답은 ‘' + q.choices[q.answer] + '’'}</span><button id="nextline">계속 ▷</button>`;
  $('#nextline').onclick = advance; $('.dialogue').onclick = e => { if (e.target.closest('button')) return; advance(); };
  tone(ok ? 784 : 392, .5);
}
function examScore() { const n = R.exam.filter((q, i) => state.exam[i] === q.answer).length; return { n, total: R.exam.length, pts: Math.round(n / R.exam.length * 100) }; }

/* ── 미니게임 ── */
function panel(i) { const p = poem(i); if (!p) return ''; return `<aside class="poem-panel"><div class="eyebrow">${senses[i]}의 단서</div><h3>${p.title}</h3><div class="original">${p.original}</div><details open><summary>우리말로 읽기</summary><div class="translation">${p.translation}</div></details><p class="caption">佳悠팀 작품표 · 번역 ${p.credit}</p></aside>`; }
function mission(i) {
  screen = 'game'; current = i; auto = false; const c = CH[state.chapter], g = R.games[i];
  render(`<div class="mission-screen">${bg()}${toolbar()}<div class="mission-wrap"><div class="mission-head"><div><div class="eyebrow">${c.tag} · 잃어버린 감각</div><h2>${c.title}</h2></div>${pieces()}</div><div class="work">${panel(i)}<section class="gamepanel" id="game"></section></div><div class="mission-mentor"><img src="${A + (R.outfits ? R.outfits[i] : R.sprites.base)}" alt="${R.name}"><p><b>${R.name}</b> “${R.mentorHint}”</p><button id="reread">장면 다시 읽기</button></div></div></div>`);
  bind(); $('#reread').onclick = () => { state.line = 0; showLine(); };
  ({ basket, rhythm, craft })[g.type](g, i);
}
function basket(G, gi) {
  const g = $('#game');
  g.innerHTML = `<h3>${G.title}</h3><p class="game-desc">${G.desc}</p><div class="arena" id="arena"><div class="intro-game" id="overlay"><div class="big">景</div><p>떨어지는 맞는 시어를 눌러 담거나<br>← → 키로 바구니를 움직여 받으세요.<br>${G.goal}개를 모으면 성공! 놓쳐도 계속할 수 있어요.</p><button id="begin">${G.start}</button></div><div class="basket" style="left:50%"><span>詩</span></div></div><div class="gamebar"><span class="score" id="score">${G.label} 0 / ${G.goal}</span><button class="outline" id="retry">다시 시작</button></div><div class="feedback" id="fb" role="status">시를 먼저 읽고 시작해 보세요.</div>`;
  let active = false, score = 0, x = 50, items = [], last = 0, spawn = 0, raf, seq = 0; const keys = new Set(), arena = $('#arena'), b = $('.basket');
  const keydown = e => { if (['ArrowLeft', 'ArrowRight'].includes(e.key)) { e.preventDefault(); keys.add(e.key); } }, keyup = e => keys.delete(e.key);
  window.addEventListener('keydown', keydown); window.addEventListener('keyup', keyup);
  function collect(it) {
    if (!active || it.used) return; it.used = true; it.el.remove();
    if (it.good) { score++; tone(520); $('#score').textContent = `${G.label} ${score} / ${G.goal}`; $('#fb').textContent = G.ok; if (score === G.goal) { active = false; win(gi, G.success); } }
    else { $('#fb').textContent = G.bad; tone(190); }
  }
  function frame(t) {
    if (!active) return; const dt = Math.min((t - last) / 1000 || 0, .05); last = t; spawn += dt;
    if (keys.has('ArrowLeft')) x -= dt * 60; if (keys.has('ArrowRight')) x += dt * 60; x = Math.max(10, Math.min(90, x)); b.style.left = x + '%';
    if (spawn > .95) { spawn = 0; const word = G.pool[seq++ % G.pool.length], it = { x: 15 + Math.random() * 70, y: -45, good: G.good.includes(word), used: false }; it.el = document.createElement('button'); it.el.className = 'fallword'; it.el.textContent = word; it.el.style.left = it.x + '%'; it.el.onclick = () => collect(it); arena.append(it.el); items.push(it); }
    for (const it of items) { if (it.used) continue; it.y += dt * 70; it.el.style.top = it.y + 'px'; if (it.y > arena.clientHeight - 85 && it.y < arena.clientHeight - 48 && Math.abs(it.x - x) < 8) collect(it); if (it.y > arena.clientHeight) { it.used = true; it.el.remove(); } }
    items = items.filter(it => !it.used); if (active) raf = requestAnimationFrame(frame);
  }
  $('#begin').onclick = () => { active = true; $('#overlay').remove(); $('#fb').textContent = '시 속의 풍경만 바구니에 담아 보세요.'; raf = requestAnimationFrame(frame); };
  $('#retry').onclick = () => mission(gi);
  cleanup = () => { active = false; cancelAnimationFrame(raf); window.removeEventListener('keydown', keydown); window.removeEventListener('keyup', keyup); };
}
function rhythm(G, gi) {
  const g = $('#game'), good = G.notes.filter(n => n !== G.decoy);
  g.innerHTML = `<h3>${G.title}</h3><p class="game-desc">${G.desc}</p><div class="arena" id="arena"><div class="rhythm-line"></div><div class="hit-zone"></div><div class="intro-game" id="overlay"><div class="big">聲</div><p>스페이스바 또는 아래 버튼으로 연주합니다.<br>붉은 원 안에서 맞는 시어를 ${G.goal}번 두드리세요.<br>소리를 꺼도 화면만 보고 할 수 있어요.</p><button id="begin">${G.start}</button></div></div><button class="tap" id="tap" disabled>두드리기 · SPACE</button><div class="gamebar"><span class="score" id="score">${G.label} 0 / ${G.goal}</span><button class="outline" id="retry">다시 시작</button></div><div class="feedback" id="fb" role="status">${G.intro}</div>`;
  let active = false, raf, last = 0, elapsed = 0, seq = 0, notes = [], score = 0; const arena = $('#arena');
  function hit() {
    if (!active) return; const n = notes.find(n => !n.used && Math.abs(n.x - 21) < 10);
    if (!n) { $('#fb').textContent = `조금만 기다려요. ${good.join('·')}이(가) 붉은 원에 들어오면 눌러 주세요.`; return; }
    n.used = true; n.el.remove();
    if (n.good) { score++; tone(n.text === good[0] ? 310 : 540); $('#score').textContent = `${G.label} ${score} / ${G.goal}`; $('#fb').textContent = G.ok; if (score === G.goal) { active = false; win(gi, G.success); } }
    else { $('#fb').textContent = G.bad; tone(170); }
  }
  function frame(t) {
    if (!active) return; const dt = Math.min((t - last) / 1000 || 0, .05); last = t; elapsed += dt;
    if (elapsed > 1.75) { elapsed = 0; const text = G.notes[seq++ % G.notes.length], n = { text, x: 107, good: text !== G.decoy, used: false }; n.el = document.createElement('div'); n.el.className = 'note' + (!n.good ? ' decoy' : ''); n.el.textContent = text; arena.append(n.el); notes.push(n); }
    for (const n of notes) { n.x -= dt * 25; n.el.style.left = n.x + '%'; if (n.x < -12) { n.used = true; n.el.remove(); } }
    notes = notes.filter(n => !n.used); raf = requestAnimationFrame(frame);
  }
  const key = e => { if (e.code === 'Space' && !e.repeat) { if (document.activeElement?.tagName === 'BUTTON' && document.activeElement.id !== 'tap') return; e.preventDefault(); hit(); } };
  window.addEventListener('keydown', key); $('#tap').onclick = hit;
  $('#begin').onclick = () => { active = true; $('#overlay').remove(); $('#tap').disabled = false; $('#tap').focus(); raf = requestAnimationFrame(frame); };
  $('#retry').onclick = () => mission(gi);
  cleanup = () => { active = false; cancelAnimationFrame(raf); window.removeEventListener('keydown', key); };
}
function craft(G, gi) {
  const ART = {
    bottle: `<div class="craft-object"><div class="bottle"><span>${G.glyph || '香'}</span><i id="toppings"></i></div></div>`,
    pan: `<div class="craft-object"><div class="pan"><div class="pancake" id="toppings"></div></div></div>`,
    cup: `<div class="craft-object"><div class="cup"><div class="steam" aria-hidden="true"><i></i><i></i><i></i></div><div class="cup-in" id="toppings"></div></div><div class="saucer"></div></div>`,
    portrait: `<div class="dress-character"><img id="robe" src="${A + (R.outfits ? R.outfits[4] : R.sprites.base)}" alt="${R.name}"><div id="warmcloth"></div></div>`,
  };
  let selected = [];
  $('#game').innerHTML = `<h3>${G.title}</h3><p class="game-desc">${G.desc}</p><div class="arena art-${G.art}">${ART[G.art]}<div class="fabric-label" id="picked">아직 고른 것이 없어요.</div></div><div class="choices">${G.options.map((x, i) => `<button class="choice" data-n="${i}" aria-pressed="false">${x}</button>`).join('')}</div><div class="gamebar"><button id="craft">${G.action}</button><button class="quiet" id="clear">비우기</button></div><div class="feedback" id="fb" role="status"></div><p class="caption">${G.note || ''}</p>`;
  function update() {
    document.querySelectorAll('.choice').forEach(b => { const yes = selected.includes(+b.dataset.n); b.classList.toggle('selected', yes); b.setAttribute('aria-pressed', yes); });
    $('#picked').textContent = selected.length ? selected.map(i => G.options[i]).join(' + ') : '아직 고른 것이 없어요.';
    if ($('#toppings')) $('#toppings').innerHTML = selected.map(i => `<span class="ingredient">${G.options[i]}</span>`).join('');
    if ($('#robe')) { $('#robe').style.filter = selected.length ? 'saturate(1.08) brightness(1.04)' : 'saturate(.65)'; $('#warmcloth').innerHTML = selected.map(i => '✦ ' + G.options[i]).join('<br>'); $('#warmcloth').style.opacity = selected.length ? 1 : 0; }
  }
  document.querySelectorAll('.choice').forEach(b => b.onclick = () => { const i = +b.dataset.n; selected = selected.includes(i) ? selected.filter(n => n !== i) : [...selected, i]; tone(400 + i * 50); update(); });
  $('#clear').onclick = () => { selected = []; update(); $('#fb').textContent = '다시 골라 보세요.'; };
  $('#craft').onclick = () => { if (selected.length === G.correct.length && G.correct.every(i => selected.includes(i))) win(gi, G.success); else { $('#fb').textContent = G.wrong; tone(180); } };
}
function win(i, explanation) {
  if (!state.done.includes(i)) state.done.push(i); state.phase = 'after'; state.line = 0; save(); screen = 'reward'; tone(660, .6);
  render(`<div class="reward-scene">${bg()}${portrait()}<section><div class="eyebrow">PAGE RESTORED</div><div class="fragment">${glyphs[i]}</div><h2>기억이 한 장 돌아왔다.</h2><blockquote>${R.memories[i]}</blockquote><p>${explanation}</p>${pieces()}<button id="continue">${josa(R.name, '에게', '에게')} 돌아가기 →</button></section></div>`);
  $('#continue').onclick = showLine;
}

/* ── 엔딩 ── */
function ending() {
  state.ended = true; save(); screen = 'ending'; auto = false;
  const special = state.affinity >= 9, sc = examScore();
  const grade = sc.n === sc.total ? 'A+' : sc.n === sc.total - 1 ? 'A' : sc.n >= 1 ? 'B+' : 'B';
  render(`<div class="final-screen"><div class="cover" style="background-image:url('${A}bg_library.jpg')"></div><div class="final-shade"></div><img class="end-sprite" src="${A + R.sprites.smile}" alt=""><section><span class="eyebrow">${special ? 'SPECIAL LETTER · 애제자에게' : 'ENDING · 마음에 남은 풍경'}</span><div class="bond-final">${R.name} · 사제의 정 · ${RANKS[rankOf(state.affinity)][1]}</div><h2>다 읽은 뒤에도,<br>당신이 남았다.</h2><p>시험지를 내고 나오는 길, 시집을 다시 펼쳤다.<br>${josa(R.name, '의', '의')} 구절 앞에서<br>이제는 조금 더 오래 머물 수 있었다.</p><div class="exam"><span>중국고전시가 II · 기말고사 (${R.name} 편)</span><strong>${sc.pts}<small>점</small></strong><p>맞힌 문제 ${sc.n} / ${sc.total} · 학점 ${grade}<br>“시를 다 읽었는데도, 마음은 아직 그곳에 있었다.”</p></div><div class="letter"><b>책갈피 뒷면에 남은 글</b><p>${(special ? R.endLetter.special : R.endLetter.normal).replace(/\n/g, '<br>')}</p></div><div class="actions"><button id="endbook">함께 읽은 시집</button><button id="endother" class="pill">다른 스승 만나기 <i>→</i></button><button id="endtitle">타이틀로</button></div><p class="caption">${R.name} 편 완결 · 이야기와 성적은 게임 속 설정입니다.</p></section></div>`);
  $('#endbook').onclick = openbook; $('#endtitle').onclick = title; $('#endother').onclick = select;
}

/* ── 모달 ── */
function modal(t, html) { clearTimeout(autoTimer); $('#modal-title').textContent = t; $('#bookbody').innerHTML = html; $('#book').showModal(); }
$('#closebook').onclick = () => { $('#book').close(); if (auto && screen === 'story') scheduleAuto(); };
$('#book').addEventListener('cancel', () => { if (auto && screen === 'story') scheduleAuto(); });
function openbook() { modal(`시집 · ${R.name}의 다섯 작품`, `<p class="modal-intro">원문과 번역은 佳悠팀 작품표를 따릅니다.</p>${senses.map((s, i) => { const p = poem(i); if (!p) return ''; return `<details class="bookentry"><summary>${state.done.includes(i) ? '✦' : '◇'} ${s} · ${p.title}</summary><pre>${p.original}</pre><p>${p.translation}</p><small>번역 ${p.credit}</small></details>`; }).join('')}`); }
function logs() { modal('대화 기록', state.history.length ? state.history.map(x => `<div class="logline"><b>${esc(x.who || '이야기')}</b><p>${esc(x.text)}</p></div>`).join('') : '<p>아직 기록된 대화가 없습니다.</p>'); }
function menu() {
  const manual = readSave(R.id, '-manual');
  modal('여정 메뉴', `<div class="menu-grid"><button id="manualsave">현재 장면 저장</button><button id="manualload" ${manual ? '' : 'disabled'}>수동 저장 불러오기${manual ? ' · ' + CH[manual.chapter].tag : ''}</button><button id="chaptersbtn">장별 다시 보기</button><button id="otherbtn">다른 스승 고르기</button><button id="creditsbtn">작품과 제작 노트</button><button id="menutitle">타이틀 화면</button></div><p>자동 저장은 스승마다 따로 이루어집니다. 미니게임 도중 불러오면 해당 게임 처음부터 시작합니다.</p>`);
  $('#manualsave').onclick = () => { if (save('-manual')) toast('현재 장면을 저장했어요.'); };
  $('#manualload').onclick = () => { state = manual; $('#book').close(); resume(); };
  $('#menutitle').onclick = () => { $('#book').close(); title(); };
  $('#otherbtn').onclick = () => { $('#book').close(); select(); };
  $('#creditsbtn').onclick = () => { $('#book').close(); credits(); };
  $('#chaptersbtn').onclick = () => {
    const f = state.furthest || 0, open = i => i === 0 || (i < 6 ? f >= 1 : i === 6 ? state.done.length >= 5 : f >= i);
    $('#bookbody').innerHTML = CH.map((c, i) => `<button class="chapterjump" data-chapter="${i}" ${open(i) ? '' : 'disabled'}>${c.tag} · ${c.title} ${open(i) ? '' : '🔒'}</button>`).join('');
    document.querySelectorAll('[data-chapter]').forEach(b => b.onclick = () => { state.chapter = +b.dataset.chapter; state.line = 0; state.phase = 'lines'; state.ended = false; state.hub = false; $('#book').close(); save(); chapterCard(); });
  };
}
function credits() {
  const tr = ROUTES.map(r => { const p = POEMS.find(p => p.poet.startsWith(r.name)); return `${r.name}(${r.han}) — 번역 ${p ? p.credit : ''}`; }).join('<br>');
  modal('작품과 제작 노트', `<h3>詩:그널 — 다섯 스승 편</h3><p>기말고사 공부 중 도서관에서 잠든 ‘나’가 송나라의 시인 한 명을 스승으로 만나, 그의 시 다섯 수를 오감으로 되찾고 다시 도서관으로 돌아와 시험을 치르는 비주얼노벨 프로토타입입니다.</p><p>원문·번역: 26-2 중국고전시가 II 佳悠팀 작품 번역본<br>${tr}</p><p>대사·사건·미니게임(향 만들기, 요리, 옷차림 등)은 감각을 체험하기 위한 각색입니다. 작품 속 표현과의 차이는 각 미니게임 아래에 적어 두었습니다.</p><p>인물·의상은 동양풍 판타지 일러스트로 새로 그린 것이며 역사적 초상이나 복식을 재현한 것이 아닙니다. 음악은 브라우저에서 실시간으로 합성하는 오음음계 곡입니다(외부 음원 없음).</p><p>PC와 모바일 지원 · 스승 한 명당 약 15–20분 · 선택에 따라 마지막 편지가 달라집니다.</p>`);
}
window.addEventListener('keydown', e => { if ($('#book').open) return; if ((e.key === 'Enter' || e.code === 'Space') && screen === 'story' && document.activeElement?.tagName !== 'BUTTON') { e.preventDefault(); advance(); } });
title();
